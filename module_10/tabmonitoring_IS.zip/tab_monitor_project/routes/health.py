from flask import Blueprint, jsonify, current_app
from pymongo import MongoClient
from datetime import datetime, timezone

health_bp = Blueprint("health", __name__)


@health_bp.route("/api/tab-monitor/health", methods=["GET"])
def health_check():
    mongo_ok = True
    mongo_error = None

    try:
        client = MongoClient(
            current_app.config["MONGO_URI"],
            serverSelectionTimeoutMS=2000,
        )
        client.server_info()
        client.close()
    except Exception as exc:
        mongo_ok = False
        mongo_error = str(exc)

    status = "healthy" if mongo_ok else "unhealthy"
    http_code = 200 if mongo_ok else 503

    response_body = {
        "module": "Module_10_TabMonitor",
        "status": status,
        "dependencies": ["mongodb"],
        "version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    if not mongo_ok:
        response_body["error"] = f"MongoDB unreachable: {mongo_error}"

    return jsonify(response_body), http_code

from flask import Blueprint, request, jsonify, current_app
from pymongo import MongoClient, DESCENDING
from datetime import datetime, timezone
import requests

from jwt_validator import validate_jwt
from logging_gateway import send_log
from config import Config

tab_monitor_bp = Blueprint("tab_monitor", __name__)


def get_db():
    client = MongoClient(current_app.config["MONGO_URI"])
    return client["exam_security"]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _error(code: int, message: str):
    return (
        jsonify({"status": "error", "error_code": code, "message": message, "timestamp": _now_iso()}),
        code,
    )


def get_exam_state(exam_id: str) -> str:
    try:
        url = f"{current_app.config['EXAM_STATE_URL']}/{exam_id}"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            return resp.json().get("data", {}).get("state", "UNKNOWN")
    except Exception:
        pass
    return "UNKNOWN"


@tab_monitor_bp.route("/api/tab-monitor/detect", methods=["POST"])
@validate_jwt
def detect_tab_switch():
    body = request.get_json(silent=True)
    if not body:
        return _error(400, "JSON request body is required")

    user_id = body.get("user_id", "").strip()
    exam_id = body.get("exam_id", "").strip()
    event_type = body.get("event_type", "").strip().upper()
    duration_seconds = int(body.get("duration_seconds", 0))

    if not user_id or not exam_id or not event_type:
        return _error(400, "user_id, exam_id, and event_type are all required")

    if event_type not in ("APP_BACKGROUND", "APP_FOREGROUND"):
        return _error(400, "event_type must be 'APP_BACKGROUND' or 'APP_FOREGROUND'")

    jwt_user_id = request.jwt_payload.get("user_id")
    jwt_role = request.jwt_payload.get("role")

    if jwt_role != "student":
        return _error(403, "Forbidden: only students report monitoring events")

    if jwt_user_id != user_id:
        send_log(
            Config.MODULE_NAME, "SECURITY", jwt_user_id, exam_id,
            "jwt_user_mismatch_attempt",
            {"jwt_user": jwt_user_id, "reported_user": user_id},
        )
        return _error(403, "Forbidden: JWT user_id does not match reported user_id")

    exam_state = get_exam_state(exam_id)
    if exam_state not in ("IN_PROGRESS", "UNKNOWN"):
        return _error(409, f"Tab monitoring is only active during IN_PROGRESS state. Current exam state: {exam_state}")

    try:
        db = get_db()

        existing_switch_count = db.tab_events.count_documents({
            "user_id": user_id,
            "exam_id": exam_id,
            "event_type": "APP_BACKGROUND",
        })

        event_doc = {
            "user_id": user_id,
            "exam_id": exam_id,
            "event_type": event_type,
            "duration_seconds": duration_seconds,
            "timestamp": _now_iso(),
            "session_id": request.jwt_payload.get("session_id"),
            "device_fingerprint_hash": request.jwt_payload.get("device_fingerprint_hash"),
        }

        new_switch_count = existing_switch_count
        if event_type == "APP_BACKGROUND":
            new_switch_count += 1
            event_doc["switch_number"] = new_switch_count

        result = db.tab_events.insert_one(event_doc)

        log_level = "SECURITY" if event_type == "APP_BACKGROUND" else "INFO"
        log_action = "tab_switch_detected" if event_type == "APP_BACKGROUND" else "app_resumed"
        send_log(
            module=Config.MODULE_NAME,
            level=log_level,
            user_id=user_id,
            exam_id=exam_id,
            action=log_action,
            details={
                "event_type": event_type,
                "switch_number": new_switch_count if event_type == "APP_BACKGROUND" else None,
                "duration_seconds": duration_seconds,
                "session_id": request.jwt_payload.get("session_id"),
            },
        )

        is_warning = new_switch_count >= Config.TAB_SWITCH_WARNING_THRESHOLD

        return jsonify({
            "status": "success",
            "data": {
                "event_id": str(result.inserted_id),
                "tab_switch_count": new_switch_count,
                "event_type": event_type,
                "warning": is_warning,
            },
            "message": (
                f"Tab switch #{new_switch_count} recorded – HIGH RISK"
                if is_warning else "Tab switch event recorded"
            ),
        }), 200

    except Exception as exc:
        send_log(Config.MODULE_NAME, "ERROR", user_id, exam_id, "tab_monitor_server_error", {"error": str(exc)})
        return _error(500, "Internal server error")


@tab_monitor_bp.route("/api/tab-monitor/events/<exam_id>", methods=["GET"])
@validate_jwt
def get_tab_events(exam_id: str):
    jwt_role = request.jwt_payload.get("role")
    if jwt_role != "teacher":
        return _error(403, "Forbidden: only teachers can view tab events")

    user_id_filter = request.args.get("user_id", "").strip()

    try:
        db = get_db()
        query = {"exam_id": exam_id}
        if user_id_filter:
            query["user_id"] = user_id_filter

        events = list(db.tab_events.find(query, {"_id": 0}).sort("timestamp", DESCENDING))

        return jsonify({
            "status": "success",
            "data": {
                "exam_id": exam_id,
                "total": len(events),
                "events": events,
            },
            "message": "Events retrieved successfully",
        }), 200

    except Exception as exc:
        return _error(500, str(exc))


@tab_monitor_bp.route("/api/tab-monitor/summary/<exam_id>", methods=["GET"])
@validate_jwt
def get_tab_summary(exam_id: str):
    jwt_role = request.jwt_payload.get("role")
    if jwt_role != "teacher":
        return _error(403, "Forbidden: only teachers can view summaries")

    try:
        db = get_db()
        pipeline = [
            {"$match": {"exam_id": exam_id, "event_type": "APP_BACKGROUND"}},
            {
                "$group": {
                    "_id": "$user_id",
                    "tab_switch_count": {"$sum": 1},
                    "first_switch": {"$min": "$timestamp"},
                    "last_switch": {"$max": "$timestamp"},
                    "total_away_sec": {"$sum": "$duration_seconds"},
                }
            },
            {"$sort": {"tab_switch_count": -1}},
        ]

        raw = list(db.tab_events.aggregate(pipeline))

        summary = []
        for row in raw:
            summary.append({
                "user_id": row["_id"],
                "tab_switch_count": row["tab_switch_count"],
                "first_switch": row.get("first_switch"),
                "last_switch": row.get("last_switch"),
                "total_away_sec": row.get("total_away_sec", 0),
                "risk_flag": row["tab_switch_count"] >= Config.TAB_SWITCH_WARNING_THRESHOLD,
            })

        return jsonify({
            "status": "success",
            "data": {"exam_id": exam_id, "summary": summary},
            "message": "Summary retrieved",
        }), 200

    except Exception as exc:
        return _error(500, str(exc))


@tab_monitor_bp.route("/api/tab-monitor/risk-data", methods=["GET"])
@validate_jwt
def get_risk_data():
    user_id = request.args.get("user_id", "").strip()
    exam_id = request.args.get("exam_id", "").strip()

    if not user_id or not exam_id:
        return _error(400, "Query parameters user_id and exam_id are both required")

    try:
        db = get_db()

        tab_switch_count = db.tab_events.count_documents({
            "user_id": user_id,
            "exam_id": exam_id,
            "event_type": "APP_BACKGROUND",
        })

        pipeline = [
            {
                "$match": {
                    "user_id": user_id,
                    "exam_id": exam_id,
                    "event_type": "APP_BACKGROUND",
                }
            },
            {"$group": {"_id": None, "total": {"$sum": "$duration_seconds"}}},
        ]
        agg_result = list(db.tab_events.aggregate(pipeline))
        total_away_s = agg_result[0]["total"] if agg_result else 0

        now = _now_iso()

        return jsonify({
            "status": "success",
            "data": {
                "module": Config.MODULE_NAME,
                "data": [
                    {
                        "user_id": user_id,
                        "exam_id": exam_id,
                        "timestamp": now,
                        "metric": "tab_switch_count",
                        "value": tab_switch_count,
                    },
                    {
                        "user_id": user_id,
                        "exam_id": exam_id,
                        "timestamp": now,
                        "metric": "total_away_seconds",
                        "value": total_away_s,
                    },
                ],
            },
            "message": "Risk data retrieved",
        }), 200

    except Exception as exc:
        return _error(500, str(exc))

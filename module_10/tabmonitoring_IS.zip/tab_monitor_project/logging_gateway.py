import requests
from datetime import datetime, timezone
from flask import current_app


def send_log(module: str, level: str, user_id: str, exam_id: str, action: str, details: dict = None) -> bool:
    if details is None:
        details = {}

    payload = {
        "module": module,
        "level": level,
        "user_id": user_id,
        "exam_id": exam_id,
        "action": action,
        "details": details,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    try:
        response = requests.post(
            current_app.config["LOG_GATEWAY_URL"],
            json=payload,
            timeout=5,
        )
        if response.status_code == 202:
            return True
        print(f"[LOG GATEWAY WARNING] Unexpected status {response.status_code}: {payload}")
        return False

    except requests.exceptions.ConnectionError:
        print(f"[LOG GATEWAY OFFLINE] FALLBACK CONSOLE LOG: {payload}")
        return False

    except requests.exceptions.Timeout:
        print(f"[LOG GATEWAY TIMEOUT] FALLBACK CONSOLE LOG: {payload}")
        return False

    except Exception as exc:
        print(f"[LOG GATEWAY ERROR] {exc}: {payload}")
        return False

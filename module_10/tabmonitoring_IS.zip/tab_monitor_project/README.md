# Module 10 – Tab Monitoring

## Overview

This module detects app switching during online exams. When a student minimizes the exam app on their Android device, the event is reported to this backend, stored, and counted toward a risk score. Teachers can view per-student summaries, and Module 17 (Risk Scoring) pulls metrics from this module to compute overall exam integrity scores.

## Security Concept

**Threat:** A student minimizes the exam app, opens a browser or messaging app to look up answers, and returns before any human proctor notices.

**Defense:** The Android client uses `ProcessLifecycleOwner` to detect foreground/background transitions and immediately reports each event to this server. The server counts switches per student and flags accounts that exceed the threshold.

## Project Structure

```
.
├── app.py
├── config.py
├── jwt_validator.py
├── logging_gateway.py
├── requirements.txt
├── .env.example
└── routes/
    ├── __init__.py
    ├── health.py
    └── tab_monitor.py
```

## Setup

### Prerequisites

- Python 3.10+
- MongoDB running locally or via URI

### Installation

```bash
pip install -r requirements.txt
```

### Configuration

Copy `.env.example` to `.env` and fill in the values:

```bash
cp .env.example .env
```

| Variable | Default | Description |
|---|---|---|
| `MONGO_URI` | `mongodb://localhost:27017/exam_security` | MongoDB connection string |
| `JWT_SECRET` | *(set by instructor)* | Shared secret for JWT verification |
| `LOG_GATEWAY_URL` | `http://localhost:5012/api/logs/write` | Module 12/13 logging endpoint |
| `EXAM_STATE_URL` | `http://localhost:5001/api/exam/state` | Module 1 exam state endpoint |
| `PORT` | `5010` | Port this service listens on |

### Running

```bash
python app.py
```

The server starts on `http://0.0.0.0:5010`.

---

## API Reference

All endpoints except `/health` require a valid JWT in the `Authorization: Bearer <token>` header.

---

### Health Check

**GET** `/api/tab-monitor/health`

No authentication required. Returns MongoDB connectivity status.

**Response 200:**
```json
{
  "module": "Module_10_TabMonitor",
  "status": "healthy",
  "dependencies": ["mongodb"],
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Response 503** when MongoDB is unreachable.

---

### Report Tab Switch Event

**POST** `/api/tab-monitor/detect`

Called by the Android client when the exam app enters background or foreground.

**Role required:** `student`

**Request Body:**
```json
{
  "user_id": "student_abc",
  "exam_id": "exam_xyz",
  "event_type": "APP_BACKGROUND",
  "duration_seconds": 0
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `user_id` | string | Yes | Must match the JWT `user_id` |
| `exam_id` | string | Yes | The active exam ID |
| `event_type` | string | Yes | `APP_BACKGROUND` or `APP_FOREGROUND` |
| `duration_seconds` | integer | No | Seconds spent outside the app (set on `APP_FOREGROUND`) |

**Response 200:**
```json
{
  "status": "success",
  "data": {
    "event_id": "66a1b2c3...",
    "tab_switch_count": 2,
    "event_type": "APP_BACKGROUND",
    "warning": false
  },
  "message": "Tab switch event recorded"
}
```

`warning` becomes `true` when `tab_switch_count` reaches or exceeds the configured threshold (default: 3).

**Error Codes:**

| Code | Reason |
|---|---|
| 400 | Missing or invalid fields |
| 401 | Missing, expired, or invalid JWT |
| 403 | JWT user does not match `user_id`, or role is not `student` |
| 409 | Exam is not in `IN_PROGRESS` state |
| 500 | Internal server error |

---

### Get Raw Events

**GET** `/api/tab-monitor/events/<exam_id>?user_id=<optional>`

Returns all tab-switch events for an exam. Sorted by timestamp descending.

**Role required:** `teacher`

**Query Parameters:**

| Param | Required | Description |
|---|---|---|
| `user_id` | No | Filter results to a specific student |

**Response 200:**
```json
{
  "status": "success",
  "data": {
    "exam_id": "exam_xyz",
    "total": 4,
    "events": [
      {
        "user_id": "student_abc",
        "exam_id": "exam_xyz",
        "event_type": "APP_BACKGROUND",
        "duration_seconds": 0,
        "timestamp": "2024-01-15T10:45:00Z",
        "switch_number": 2
      }
    ]
  },
  "message": "Events retrieved successfully"
}
```

---

### Get Per-Student Summary

**GET** `/api/tab-monitor/summary/<exam_id>`

Returns an aggregated summary of tab switches per student, sorted by switch count descending.

**Role required:** `teacher`

**Response 200:**
```json
{
  "status": "success",
  "data": {
    "exam_id": "exam_xyz",
    "summary": [
      {
        "user_id": "student_abc",
        "tab_switch_count": 7,
        "first_switch": "2024-01-15T10:05:00Z",
        "last_switch": "2024-01-15T10:45:00Z",
        "total_away_sec": 340,
        "risk_flag": true
      }
    ]
  },
  "message": "Summary retrieved"
}
```

---

### Get Risk Data (Module 17 Integration)

**GET** `/api/tab-monitor/risk-data?user_id=<id>&exam_id=<id>`

Provides tab-switch metrics to the Risk Scoring module (Module 17).

**Role required:** Any valid JWT role

**Query Parameters:**

| Param | Required | Description |
|---|---|---|
| `user_id` | Yes | Student ID |
| `exam_id` | Yes | Exam ID |

**Response 200:**
```json
{
  "status": "success",
  "data": {
    "module": "Module_10_TabMonitor",
    "data": [
      {
        "user_id": "student_abc",
        "exam_id": "exam_xyz",
        "timestamp": "2024-01-15T10:50:00Z",
        "metric": "tab_switch_count",
        "value": 5
      },
      {
        "user_id": "student_abc",
        "exam_id": "exam_xyz",
        "timestamp": "2024-01-15T10:50:00Z",
        "metric": "total_away_seconds",
        "value": 120
      }
    ]
  },
  "message": "Risk data retrieved"
}
```

---

## Integration Notes

- **JWT:** All protected endpoints verify the `Authorization: Bearer <token>` header using HS256 and the shared `JWT_SECRET`. Expired or malformed tokens return HTTP 401.
- **Logging:** This module never writes directly to a MongoDB log collection. All audit entries go through the Logging Gateway at `LOG_GATEWAY_URL` (HTTP POST, expects HTTP 202). If the gateway is unreachable, events are printed to console as a fallback.
- **Exam State:** Before recording a switch event, the module queries Module 1's state endpoint. Events are accepted only when the exam is `IN_PROGRESS` (or when Module 1 is unreachable, to avoid data loss during transient outages).
- **Risk Threshold:** Students with `tab_switch_count >= TAB_SWITCH_WARNING_THRESHOLD` (default 3) are flagged as HIGH RISK. The Android client receives a `warning: true` flag and should display an in-app alert.

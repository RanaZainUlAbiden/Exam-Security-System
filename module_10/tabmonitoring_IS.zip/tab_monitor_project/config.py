import os


class Config:
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/exam_security")
    JWT_SECRET = os.environ.get("JWT_SECRET", "shared_secret_key_from_instructor")
    LOG_GATEWAY_URL = os.environ.get("LOG_GATEWAY_URL", "http://localhost:5012/api/logs/write")
    EXAM_STATE_URL = os.environ.get("EXAM_STATE_URL", "http://localhost:5001/api/exam/state")
    MODULE_NAME = "Module_10_TabMonitor"
    MODULE_VERSION = "1.0.0"
    PORT = int(os.environ.get("PORT", 5010))
    TAB_SWITCH_WARNING_THRESHOLD = 3

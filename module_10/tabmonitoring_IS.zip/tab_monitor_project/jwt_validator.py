import jwt
from functools import wraps
from flask import request, jsonify, current_app
from datetime import datetime, timezone


def _error_response(code: int, message: str):
    return (
        jsonify({
            "status": "error",
            "error_code": code,
            "message": message,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }),
        code,
    )


def validate_jwt(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")

        if not auth_header.startswith("Bearer "):
            return _error_response(401, "Missing or malformed Authorization header. Use: Bearer <token>")

        token = auth_header.split(" ", 1)[1].strip()

        try:
            payload = jwt.decode(
                token,
                current_app.config["JWT_SECRET"],
                algorithms=["HS256"],
            )
        except jwt.ExpiredSignatureError:
            return _error_response(401, "JWT expired")
        except jwt.InvalidSignatureError:
            return _error_response(401, "JWT signature verification failed")
        except jwt.DecodeError:
            return _error_response(401, "JWT decode error – token is malformed")
        except jwt.InvalidTokenError as exc:
            return _error_response(401, f"Invalid JWT: {str(exc)}")

        request.jwt_payload = payload
        return f(*args, **kwargs)

    return decorated_function

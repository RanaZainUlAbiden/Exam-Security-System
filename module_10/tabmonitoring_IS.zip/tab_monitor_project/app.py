from flask import Flask
from routes.tab_monitor import tab_monitor_bp
from routes.health import health_bp
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

app.register_blueprint(tab_monitor_bp)
app.register_blueprint(health_bp)

if __name__ == "__main__":
    print(f"[Module 10] Tab Monitor running on port {Config.PORT}")
    app.run(debug=True, port=Config.PORT, host="0.0.0.0")
